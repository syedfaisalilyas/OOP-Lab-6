﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Challenge_1.BL;

namespace Challenge_1
{
    class Program
    {
        static void Main(string[] args)
        {

            Grid a = new Grid();
            a.draw();
            Console.ReadKey();
        }
    }
}
