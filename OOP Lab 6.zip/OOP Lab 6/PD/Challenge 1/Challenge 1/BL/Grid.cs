﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1.BL
{
    class Grid
    {
       public Cell[,] maze = new Cell[24,71];
        public int rowsize;
        public int colsize;

        public Grid()
        {

        }
    public Grid(int rowsize,int colsize,string path)
        {
            this.rowsize = rowsize;
            this.colsize = colsize;
        }

    public Cell getleftcell(Cell c)
        {
             c.x--;
            return c;
        }

        public Cell getrightcell(Cell c)
        {
            c.x++;
            return c;
        } 
        
       public Cell getUpcell(Cell c)
        {
            c.y--;
            return c;
        } 
        public Cell getDowncell(Cell c)
        {
            c.y++;
            return c;
        }

       public Cell findpacman()
        {
            foreach(Cell m in maze)
            {
                if(m.x == 'P' && m.y == 'P')
                {
                    return m;
                }
            }
            return null;
        }
  
        public Cell findGhost(char ghostCharacter)
        {
            foreach (Cell m in maze)
            {
                if (m.x == ghostCharacter && m.y == ghostCharacter)
                {
                    return m;
                }
            }
            return null;
        }

        public void draw()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write("+");
            }

            for (int i = 0; i < 100; i++)
            {
                Console.SetCursorPosition(i, 40);
                Console.Write("+");
            }
            for (int i = 0; i < 40; i++)
            {
                Console.SetCursorPosition(0, i);
                Console.Write("+");
                Console.SetCursorPosition(100, i);
                Console.Write("+");
            }
        }



    }
}
