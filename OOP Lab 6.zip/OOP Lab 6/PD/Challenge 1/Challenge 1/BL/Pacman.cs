﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1.BL
{
    class Pacman
    {
        public int x;
        public int y;
        public int score;
        public Grid mazeGrid;

        public Pacman(int x,int y,Grid mazeGrid)
        {
            this.x = x;
            this.y = y;
            this.mazeGrid = mazeGrid;
        }

        public void remove()
        {

        }

        public void draw()
        {

        }

        public void moveleft(Cell current,Cell next)
        {

        } 
        public void moveRight(Cell current,Cell next)
        {

        }
         public void moveUp(Cell current,Cell next)
        {

        }
         public void moveDown(Cell current,Cell next)
        {

        }

        public void move()
        {

        }

        public void printScore()
        {

        }


    }
}
