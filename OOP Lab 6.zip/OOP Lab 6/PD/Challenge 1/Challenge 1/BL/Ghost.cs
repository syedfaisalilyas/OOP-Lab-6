﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1.BL
{
    class Ghost
    {
        public int x;
        public int y;
        public string ghostDirection;
        public char ghostCharacter;
        public float speed;
        public char previousItem;
        public float deltaChange;
        public Grid mazeGrid;

        public Ghost(int x, int y, char ghostCharacter, string ghostDirection, float speed, char previousItem, Grid mazeGrid)
        {
            this.x = x;
            this.y = y;
            this.ghostCharacter = ghostCharacter;
            this.ghostDirection = ghostDirection;
            this.speed = speed;
            this.previousItem = previousItem;
            this.mazeGrid = mazeGrid;
        }

        public void setdirection(string ghostDirection)
        {
            this.ghostDirection = ghostDirection;
        }

        public string getdirection()
        {
            return ghostDirection;
        }
        public void remove()
        {

        }

        public void draw()
        {

        }

        public char getCharacter()
        {
            return ghostCharacter;
        }

        public void changeDelta()
        {
            deltaChange = deltaChange + speed;
        }

        public float getDelta()
        {
            return deltaChange;
        }

        public void setdeltazero()
        {
            deltaChange = 0;
        }

        public void move(Grid mazegrid)
        {
            changeDelta();
            if (Math.Floor(getDelta()) == 1)
            {
                if (ghostCharacter == 'G')
                {
                    moveHorizontal(mazeGrid);
                }
                setdeltazero();
            }
        }

        public void moveHorizontal(Grid mazeGrid)
        {

        }

        public void moveVertical(Grid mazeGrid)
        {

        }

        public int GenerateRandom()
        {

        }

        public void moveRandom()
        {

        }

        public void moveSmart()
        {

        }

        public double calculateDistance(Cell current,Cell pacmanLocation)
        {

        }
    }
}
