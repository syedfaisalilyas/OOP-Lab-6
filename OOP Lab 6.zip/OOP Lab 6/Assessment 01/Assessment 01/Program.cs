﻿using Assessment_01.BL;
using Assessment_01.UI;
using Assessment_01.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01
{
    class Program
    {
        static void Main(string[] args)
        {
            CoffeeShop cfshop = new CoffeeShop();
            MenuItem item;
            CoffeeShopUI cfUI = new CoffeeShopUI();
            ShopUI shopUI = new ShopUI();
            while (true)
            {
                int choice = shopUI.Menu();
                if (choice == 1)
                {
                    item = cfUI.AddItemInMenu();
                    cfUI.validityFunction(item); 
                    cfshop.viewItems();
                }
                else if (choice == 2)
                {
                    cfUI.addOrder();
                    cfshop.viewOrders();
                }
                else if (choice == 3)
                {
                    cfUI.DisplayFulfillOrders();
                }
                else if (choice == 4)
                {
                    cfUI.ListofTakenorders();
                }
                else if (choice == 5)
                {
                    cfUI.DisplayAmount();
                }
                else if (choice == 6)
                {
                    cfUI.FindItemOfCheapestPrice();
                }
                else if (choice == 7)
                {
                    cfUI.ViewByCategory("drink");
                }
                else if (choice == 8)
                {
                    cfUI.ViewByCategory("food");
                }
                else
                {
                    break;
                }
                shopUI.GetchALternative();
            }

            Console.ReadLine();

        }


    }
}
