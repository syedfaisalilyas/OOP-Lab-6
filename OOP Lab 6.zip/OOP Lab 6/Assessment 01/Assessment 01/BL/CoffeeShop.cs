﻿using Assessment_01.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01.BL
{
    class CoffeeShop
    {

        static public string name;
        static public List<MenuItem> menuItems = new List<MenuItem>();
        static public List<string> orders = new List<string>();
        CoffeeShopDL coffeeShopDL = new CoffeeShopDL();
        // extra
        public void viewItems()
        {
            foreach (MenuItem item in menuItems)
            {
                Console.WriteLine(item.name);
                Console.WriteLine(item.type);
                Console.WriteLine(item.price);
            }
        }
        public void viewOrders()
        {
            foreach (string o in orders)
            {
                Console.WriteLine(o);

            }
        }

        public List<string> fulfillOrder()
        {
            List<string> list = new List<string>();
            if (orders != null)
            {
                foreach (string o in orders)
                {
                    list = returnOrders();
                }

            }
            return list;
        }
        public List<string> returnOrders()
        {
            return orders;
        }
        public bool isItemAlreadyExist(MenuItem item)
        {
            foreach (MenuItem m in menuItems)
            {
                if (m.name == item.name && m.type == item.type)
                {
                    return true;
                }
            }
            return false;
        }
        public double CalculateAmount()
        {
            double amount = 0;

            foreach (MenuItem m in menuItems)
            {
                amount = amount + m.price;
            }
            return amount;
        }
        public MenuItem FindCheapestItem()
        {
            double number = menuItems[0].price;
            MenuItem item = new MenuItem();
            foreach (MenuItem m in menuItems)
            {
                if (number > m.price)
                {

                    item = m;
                }
            }
            return item;
        }
        public List<MenuItem> ViewByCategory(string type)
        {
            List<MenuItem> filtered = new List<MenuItem>();
            foreach (MenuItem m in menuItems)
            {
                if (m.type == type)
                {
                    filtered.Add(m);
                }
            }
            return filtered;
        }
    }
}
