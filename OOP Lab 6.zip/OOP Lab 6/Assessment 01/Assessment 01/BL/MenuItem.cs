﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01.BL
{
class MenuItem
    {
        public string name;
        public string type;
        public double price;
        public MenuItem() { }
        public MenuItem(string name, string type, double price)
        {
            this.name = name;
            this.type = type;
            this.price = price;

        }

    }
}
