﻿using Assessment_01.BL;
using Assessment_01.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01.UI
{
    class CoffeeShopUI
    {
        public MenuItem AddItemInMenu()
        {
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter type");
            string type = Console.ReadLine();
            Console.WriteLine("Enter price");
            double price = double.Parse(Console.ReadLine());
            MenuItem item = new MenuItem(name, type, price);
            return item;
        }
        public void addOrder()
        {
            Console.WriteLine("Enter name of item");
            string name = Console.ReadLine();
            CoffeeShop cfshop = new CoffeeShop();
            CoffeeShopDL cfdl = new CoffeeShopDL();
            bool isAdded = cfdl.AddOrder(name);
            if (isAdded == true)
            {
                Console.WriteLine("Successfully added");
            }
            else
            {
                Console.WriteLine("This item is currently unavailable!");
            }
        }
        public void DisplayFulfillOrders()
        {
            CoffeeShop cfShop = new CoffeeShop();
            if (cfShop.fulfillOrder() != null)
            {
                List<string> listoforders = cfShop.fulfillOrder();
                foreach (string order in listoforders)
                {
                    Console.WriteLine("{0} is ready", order);
                }
            }
            else
            {
                Console.WriteLine("All orders have been fulfilled!");
            }
        }
        public void ListofTakenorders()
        {
            CoffeeShop cfShop = new CoffeeShop();
            if (cfShop.returnOrders() != null)
            {
                List<string> listoforders = cfShop.returnOrders();
                foreach (string order in listoforders)
                {
                    Console.WriteLine(order);
                }
            }
            else
            {
                Console.WriteLine("NO ORDERS!");
            }

        }
        public void DisplayAmount()
        {
            CoffeeShop cf = new CoffeeShop();
            double amount = cf.CalculateAmount();
            Console.WriteLine(amount);
        }
        public void FindItemOfCheapestPrice()
        {
            CoffeeShop cf = new CoffeeShop();
            MenuItem item;
            item = cf.FindCheapestItem();
            Console.WriteLine("Name\tPrice");
            Console.WriteLine(item.name + "\t" + item.price);
        }
        public void ViewByCategory(string type)
        {

            CoffeeShop cf = new CoffeeShop();
            List<MenuItem> filtered = new List<MenuItem>();
            filtered = cf.ViewByCategory(type);
            Console.WriteLine("Name\t\tType\t\tPrice");
            foreach (MenuItem item in filtered)
            {
                Console.WriteLine(item.name + "\t\t" + item.type + "\t\t" + item.price);
            }
            Console.WriteLine();
        }
        public void validityFunction(MenuItem item)
        {
            CoffeeShop cfshop = new CoffeeShop();
            CoffeeShopDL cfDl = new CoffeeShopDL();
            if (cfshop.isItemAlreadyExist(item) == false)
            {
                cfDl.AddMenuItem(item);
                Console.WriteLine("Successfully added");
            }
            else
            {
                Console.WriteLine("Item already exist!");
            }
        }
    }
}
