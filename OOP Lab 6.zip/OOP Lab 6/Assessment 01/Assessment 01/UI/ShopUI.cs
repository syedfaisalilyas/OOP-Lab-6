﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01.UI
{
    class ShopUI
    {
        public int Menu()
        {
            Console.WriteLine(" 1.ADD ITEM IN MENU \n 2.ADD AN ORDER \n 3.DISPLAY FULFILL ORDER \n 4.VIEW ORDERS \n 5.VIEW AMOUNT \n 6.VIEW THE CHEAPEST ITEM \n 7.VIEW DRINKS ONLY \n 8.VIEW FOOD ITEMS ONLY");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        public void GetchALternative()
        {
            Console.WriteLine("PRESS ANY KEY TO CONTINUE!");
            Console.ReadLine();
            Console.Clear();
        }

    }
}
