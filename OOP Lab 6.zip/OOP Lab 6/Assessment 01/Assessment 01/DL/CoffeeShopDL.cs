﻿using Assessment_01.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_01.DL
{
    class CoffeeShopDL
    {
        public List<CoffeeShop> listofCoffeeShop = new List<CoffeeShop>();

        public CoffeeShopDL() { }


        public CoffeeShopDL(string name)
        {
            CoffeeShop.name = name;
        }
        public void AddMenuItem(MenuItem item)
        {
            CoffeeShop.menuItems.Add(item);

        }
        public bool AddOrder(string name)
        {
            foreach (MenuItem m in CoffeeShop.menuItems)
            {
                if (m.name == name)
                {
                    AddOrderIntoList(name);
                    return true;
                }
            }
            return false;
        }
        public void AddOrderIntoList(string item)
        {

            CoffeeShop.orders.Add(item);
        }
    }
}
