﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Challenge_1.UI;
using Challenge_1.DL;
using Challenge_1.BL;

namespace Challenge_1
{
    class Program
    {
        static bool Main(string[] args)
        {
            CoffeeShopUI m = new CoffeeShopUI();
            int choice = int.Parse(Console.ReadLine());
            while (true)
            { 
                m.Menu();
                if(choice == 1)
                { 

                }
            }
        }
    }
}
