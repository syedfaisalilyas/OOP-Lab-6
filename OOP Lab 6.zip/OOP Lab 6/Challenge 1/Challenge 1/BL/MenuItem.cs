﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1.BL
{
    class MenuItem
    {
        public string itemname;
        public string type;
        public int price;

        public MenuItem()
        {

        }
        public MenuItem(string itemname, string type,int price)
        {
            this.itemname = itemname;
            this.type = type;
            this.price = price;

        }
    }
}
